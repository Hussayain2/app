import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express from "express";
import { 
  insertUserSchema, insertAppointmentSchema, insertMedicalHistorySchema, 
  insertNotificationSchema, insertMessageSchema, insertSettingsSchema,
  insertTreatmentSchema
} from "@shared/schema";
import { format } from "date-fns";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes with /api prefix
  app.use(express.json());

  // User routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      // Initialize user settings
      await storage.createSettings({
        userId: user.id,
        notifications: true,
        smsAlerts: true,
        emailUpdates: false
      });
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Create session (simplified for in-memory storage)
      req.session.userId = user.id;
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Login failed", error });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Return user without password
    const { password, ...userWithoutPassword } = user;
    res.status(200).json(userWithoutPassword);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed", error: err });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.put("/api/users/:id", async (req, res) => {
    const userId = parseInt(req.params.id);
    const sessionUserId = req.session.userId;
    
    if (!sessionUserId || sessionUserId !== userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const userData = req.body;
      const updatedUser = await storage.updateUser(userId, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = updatedUser;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Failed to update user", error });
    }
  });

  // Appointment routes
  app.get("/api/appointments", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const appointments = await storage.getAppointmentsByUserId(userId);
    res.status(200).json(appointments);
  });

  app.post("/api/appointments", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const appointmentData = insertAppointmentSchema.parse({ ...req.body, userId });
      const appointment = await storage.createAppointment(appointmentData);
      
      // Add loyalty points for booking an appointment
      await storage.addLoyaltyPoints(userId, 50);
      
      // Create a notification for the new appointment
      const date = new Date(appointmentData.date);
      const formattedDate = format(date, "MMMM d, yyyy");
      
      await storage.createNotification({
        userId,
        title: "Appointment Confirmed",
        message: `Your appointment is scheduled for ${formattedDate} at ${appointmentData.time}.`,
        type: "appointment"
      });
      
      res.status(201).json(appointment);
    } catch (error) {
      res.status(400).json({ message: "Invalid appointment data", error });
    }
  });

  app.put("/api/appointments/:id", async (req, res) => {
    const appointmentId = parseInt(req.params.id);
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const appointment = await storage.getAppointment(appointmentId);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      if (appointment.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this appointment" });
      }
      
      const updatedAppointment = await storage.updateAppointment(appointmentId, req.body);
      
      // Create a notification for the updated appointment
      if (updatedAppointment) {
        const date = new Date(updatedAppointment.date);
        const formattedDate = format(date, "MMMM d, yyyy");
        
        await storage.createNotification({
          userId,
          title: "Appointment Updated",
          message: `Your appointment has been rescheduled to ${formattedDate} at ${updatedAppointment.time}.`,
          type: "appointment"
        });
      }
      
      res.status(200).json(updatedAppointment);
    } catch (error) {
      res.status(400).json({ message: "Failed to update appointment", error });
    }
  });

  app.delete("/api/appointments/:id", async (req, res) => {
    const appointmentId = parseInt(req.params.id);
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const appointment = await storage.getAppointment(appointmentId);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      if (appointment.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete this appointment" });
      }
      
      const deleted = await storage.deleteAppointment(appointmentId);
      
      if (deleted) {
        // Create a notification for the canceled appointment
        await storage.createNotification({
          userId,
          title: "Appointment Canceled",
          message: "Your appointment has been canceled successfully.",
          type: "appointment"
        });
      }
      
      res.status(200).json({ success: deleted });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete appointment", error });
    }
  });

  // Medical History routes
  app.get("/api/medical-history", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const medicalHistory = await storage.getMedicalHistory(userId);
    
    if (!medicalHistory) {
      return res.status(404).json({ message: "Medical history not found" });
    }
    
    res.status(200).json(medicalHistory);
  });

  app.post("/api/medical-history", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const medicalHistoryData = insertMedicalHistorySchema.parse({ ...req.body, userId });
      
      // Check if medical history already exists
      const existingHistory = await storage.getMedicalHistory(userId);
      
      let medicalHistory;
      if (existingHistory) {
        // Update if exists
        medicalHistory = await storage.updateMedicalHistory(userId, medicalHistoryData);
      } else {
        // Create if doesn't exist
        medicalHistory = await storage.createMedicalHistory(medicalHistoryData);
      }
      
      res.status(201).json(medicalHistory);
    } catch (error) {
      res.status(400).json({ message: "Invalid medical history data", error });
    }
  });

  // Notification routes
  app.get("/api/notifications", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const notifications = await storage.getNotifications(userId);
    res.status(200).json(notifications);
  });

  app.put("/api/notifications/:id/read", async (req, res) => {
    const notificationId = parseInt(req.params.id);
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const updatedNotification = await storage.markNotificationAsRead(notificationId);
    
    if (!updatedNotification) {
      return res.status(404).json({ message: "Notification not found" });
    }
    
    res.status(200).json(updatedNotification);
  });

  // Message routes
  app.get("/api/messages", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const messages = await storage.getMessages(userId);
    res.status(200).json(messages);
  });

  app.post("/api/messages", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const messageData = insertMessageSchema.parse({ ...req.body, userId });
      const message = await storage.createMessage(messageData);
      
      // Create a notification for the message
      await storage.createNotification({
        userId,
        title: "Message Sent",
        message: "Your message has been sent. We will respond shortly!",
        type: "general"
      });
      
      res.status(201).json(message);
    } catch (error) {
      res.status(400).json({ message: "Invalid message data", error });
    }
  });

  // Rewards routes
  app.get("/api/rewards", async (req, res) => {
    const rewards = await storage.getRewards();
    res.status(200).json(rewards);
  });

  app.post("/api/rewards/:id/redeem", async (req, res) => {
    const rewardId = parseInt(req.params.id);
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const reward = await storage.getReward(rewardId);
      
      if (!reward) {
        return res.status(404).json({ message: "Reward not found" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (user.loyaltyPoints < reward.pointsCost) {
        return res.status(400).json({ 
          message: "Insufficient loyalty points",
          required: reward.pointsCost,
          current: user.loyaltyPoints
        });
      }
      
      // Deduct points and update user
      const updatedUser = await storage.updateUser(userId, { 
        loyaltyPoints: user.loyaltyPoints - reward.pointsCost 
      });
      
      // Create a notification for the redeemed reward
      await storage.createNotification({
        userId,
        title: "Reward Redeemed",
        message: `You have successfully redeemed ${reward.name}. You can collect it at your next visit.`,
        type: "loyalty"
      });
      
      const { password, ...userWithoutPassword } = updatedUser!;
      res.status(200).json({ 
        success: true, 
        reward,
        user: userWithoutPassword
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to redeem reward", error });
    }
  });

  // Settings routes
  app.get("/api/settings", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const settings = await storage.getSettings(userId);
    
    if (!settings) {
      return res.status(404).json({ message: "Settings not found" });
    }
    
    res.status(200).json(settings);
  });

  app.put("/api/settings", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const settingsData = req.body;
      const settings = await storage.getSettings(userId);
      
      let updatedSettings;
      if (settings) {
        updatedSettings = await storage.updateSettings(userId, settingsData);
      } else {
        updatedSettings = await storage.createSettings({ ...settingsData, userId });
      }
      
      res.status(200).json(updatedSettings);
    } catch (error) {
      res.status(400).json({ message: "Failed to update settings", error });
    }
  });

  // Referral routes
  app.post("/api/referrals", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      // In a real app, send an email to the referred person
      // For now, just simulate successful referral
      
      // Add loyalty points for referring
      const updatedUser = await storage.addLoyaltyPoints(userId, 100);
      
      // Create notification
      await storage.createNotification({
        userId,
        title: "Referral Sent",
        message: `Your referral invitation has been sent to ${email}. You've earned 100 loyalty points!`,
        type: "loyalty"
      });
      
      const { password, ...userWithoutPassword } = updatedUser!;
      res.status(200).json({ 
        success: true,
        message: "Referral sent successfully",
        user: userWithoutPassword
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to send referral", error });
    }
  });

  // Treatment History routes
  app.get("/api/treatments", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const treatments = await storage.getTreatments(userId);
    res.status(200).json(treatments);
  });

  app.get("/api/treatments/:id", async (req, res) => {
    const treatmentId = parseInt(req.params.id);
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const treatment = await storage.getTreatment(treatmentId);
    
    if (!treatment) {
      return res.status(404).json({ message: "Treatment not found" });
    }
    
    if (treatment.userId !== userId) {
      return res.status(403).json({ message: "Not authorized to view this treatment" });
    }
    
    res.status(200).json(treatment);
  });

  app.post("/api/treatments", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const treatmentData = insertTreatmentSchema.parse({ ...req.body, userId });
      const treatment = await storage.createTreatment(treatmentData);
      
      // Create a notification for the new treatment record
      await storage.createNotification({
        userId,
        title: "Treatment Record Added",
        message: `A new treatment record has been added to your dental history.`,
        type: "general"
      });
      
      res.status(201).json(treatment);
    } catch (error) {
      res.status(400).json({ message: "Invalid treatment data", error });
    }
  });

  app.put("/api/treatments/:id", async (req, res) => {
    const treatmentId = parseInt(req.params.id);
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const treatment = await storage.getTreatment(treatmentId);
      
      if (!treatment) {
        return res.status(404).json({ message: "Treatment not found" });
      }
      
      if (treatment.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this treatment" });
      }
      
      const updatedTreatment = await storage.updateTreatment(treatmentId, req.body);
      res.status(200).json(updatedTreatment);
    } catch (error) {
      res.status(400).json({ message: "Failed to update treatment", error });
    }
  });

  app.delete("/api/treatments/:id", async (req, res) => {
    const treatmentId = parseInt(req.params.id);
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const treatment = await storage.getTreatment(treatmentId);
      
      if (!treatment) {
        return res.status(404).json({ message: "Treatment not found" });
      }
      
      if (treatment.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete this treatment" });
      }
      
      const deleted = await storage.deleteTreatment(treatmentId);
      res.status(200).json({ success: deleted });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete treatment", error });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
