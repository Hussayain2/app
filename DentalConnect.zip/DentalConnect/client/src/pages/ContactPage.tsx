import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Send, Phone, Mail, User, ChevronRight } from "lucide-react";
import PageContainer from "@/components/layout/PageContainer";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Message } from "@shared/schema";
import { formatTimeAgo } from "@/lib/dates";

const messageSchema = z.object({
  message: z.string().min(1, "Please enter a message")
});

type ChatMessage = {
  id: number;
  sender: "user" | "clinic";
  content: string;
  timestamp: Date;
};

const ContactPage = () => {
  const { toast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 0,
      sender: "clinic",
      content: "👋 Hi there! How can we help you today?",
      timestamp: new Date()
    }
  ]);
  
  const messageEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  
  const form = useForm({
    resolver: zodResolver(messageSchema),
    defaultValues: {
      message: ""
    }
  });
  
  // Get existing messages
  const { data: existingMessages = [] } = useQuery<Message[]>({
    queryKey: ["/api/messages"]
  });
  
  // Convert existing messages to chat format on initial load
  useEffect(() => {
    if (existingMessages.length > 0) {
      const formattedMessages = existingMessages.map(msg => ({
        id: msg.id,
        sender: "user" as const,
        content: msg.message,
        timestamp: new Date(msg.createdAt || new Date())
      }));
      
      // Add clinic responses where applicable
      const allMessages: ChatMessage[] = [...messages];
      formattedMessages.forEach(msg => {
        allMessages.push(msg);
        
        // Simulate clinic response
        if (Math.random() > 0.3) { // Some messages might not have a response yet
          allMessages.push({
            id: msg.id * 100 + 1,
            sender: "clinic",
            content: getRandomResponse(),
            timestamp: new Date(new Date(msg.timestamp).getTime() + 1000 * 60 * Math.floor(Math.random() * 20 + 1))
          });
        }
      });
      
      // Sort by timestamp and set
      setMessages(allMessages.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime()));
    }
  }, [existingMessages.length]);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (messageEndRef.current) {
      messageEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);
  
  const onSubmit = async (data: { message: string }) => {
    // Add user message to chat
    const userMessage: ChatMessage = {
      id: messages.length + 1,
      sender: "user",
      content: data.message,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    form.reset();
    
    // Send message to API
    try {
      await apiRequest("POST", "/api/messages", {
        subject: "Chat message",
        message: data.message
      });
      
      // Simulate clinic response after a short delay
      setTimeout(() => {
        const clinicResponse: ChatMessage = {
          id: messages.length + 2,
          sender: "clinic",
          content: getRandomResponse(),
          timestamp: new Date()
        };
        setMessages(prev => [...prev, clinicResponse]);
      }, 1000);
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  return (
    <PageContainer title="Chat with Us">
      <div className="flex flex-col h-[calc(100vh-11rem)]">
        {/* Contact options */}
        <div className="flex gap-2 mb-3 text-sm text-gray-600">
          <a href="tel:+11234567890" className="flex items-center gap-1 hover:text-primary">
            <Phone className="h-3 w-3" /> (123) 456-7890
          </a>
          <span className="mx-1">•</span>
          <a href="mailto:contact@dentalclinic.com" className="flex items-center gap-1 hover:text-primary">
            <Mail className="h-3 w-3" /> contact@dentalclinic.com
          </a>
        </div>
        
        {/* Chat container */}
        <Card className="flex-1 flex flex-col overflow-hidden mb-4 border-gray-200">
          <CardContent className="p-0 flex flex-col h-full">
            {/* Chat header */}
            <div className="p-3 bg-primary/5 border-b flex items-center gap-3">
              <div className="bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center">
                <User className="h-4 w-4" />
              </div>
              <div>
                <p className="font-medium">Bright Smile Dental</p>
                <p className="text-xs text-gray-500">Usually responds within 10 minutes</p>
              </div>
            </div>
            
            {/* Messages area */}
            <div 
              className="flex-1 overflow-y-auto p-4 space-y-4"
              ref={chatContainerRef}
            >
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`max-w-[80%] p-3 rounded-lg ${
                      msg.sender === 'user' 
                        ? 'bg-primary text-white rounded-br-none' 
                        : 'bg-gray-100 text-gray-800 rounded-bl-none'
                    }`}
                  >
                    <p>{msg.content}</p>
                    <p className={`text-xs mt-1 ${
                      msg.sender === 'user' ? 'text-primary-50' : 'text-gray-500'
                    }`}>
                      {formatTimeAgo(msg.timestamp)}
                    </p>
                  </div>
                </div>
              ))}
              <div ref={messageEndRef} />
            </div>
            
            {/* Message input */}
            <div className="p-3 border-t">
              <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-end gap-2">
                <div className="flex-1">
                  <Textarea
                    placeholder="Type your message here..."
                    className="min-h-[80px] resize-none"
                    {...form.register("message")}
                  />
                  {form.formState.errors.message && (
                    <p className="text-sm text-red-500 mt-1">
                      {form.formState.errors.message.message}
                    </p>
                  )}
                </div>
                <Button type="submit" size="icon" className="rounded-full h-10 w-10">
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
};

// Helper function to get random responses
function getRandomResponse(): string {
  const responses = [
    "Thank you for your message! Our team will assist you as soon as possible.",
    "We've received your question and will get back to you shortly.",
    "Thanks for reaching out! I'll connect you with the right team member who can help with this.",
    "I understand your concern. Let me check with our specialists and get back to you soon.",
    "Thank you for contacting us. Is there anything specific about your appointment you'd like to know?",
    "We appreciate your message. Our dental team will review this and respond within 1-2 hours.",
    "Got it! I'll make sure the doctor sees this before your appointment.",
    "Thanks for your patience. We'll address this right away and get back to you."
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
}

export default ContactPage;
