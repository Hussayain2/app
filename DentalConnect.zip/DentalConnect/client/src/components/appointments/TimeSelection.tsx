import { useState } from "react";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface TimeSlot {
  time: string;
  available: boolean;
}

interface TimeSelectionProps {
  selectedDate: Date | null;
  selectedTime: string | null;
  onSelectTime: (time: string) => void;
}

const TimeSelection = ({ selectedDate, selectedTime, onSelectTime }: TimeSelectionProps) => {
  // Generate time slots from 9 AM to 5 PM in 30-minute intervals
  const morningTimeSlots: TimeSlot[] = [
    { time: "9:00 AM", available: true },
    { time: "9:30 AM", available: true },
    { time: "10:00 AM", available: true },
    { time: "10:30 AM", available: true },
    { time: "11:00 AM", available: true },
    { time: "11:30 AM", available: true },
  ];
  
  const afternoonTimeSlots: TimeSlot[] = [
    { time: "2:00 PM", available: false },
    { time: "2:30 PM", available: true },
    { time: "3:00 PM", available: true },
    { time: "3:30 PM", available: true },
    { time: "4:00 PM", available: true },
    { time: "4:30 PM", available: true },
  ];
  
  const timeSlots = [...morningTimeSlots, ...afternoonTimeSlots];
  
  if (!selectedDate) {
    return null;
  }
  
  return (
    <Card>
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-3">Select Time</h2>
        <p className="text-neutral-600 mb-4">{format(selectedDate, "MMM d, yyyy")}</p>
        
        <div className="grid grid-cols-2 gap-3">
          {timeSlots.map((slot) => (
            <button
              key={slot.time}
              className={cn(
                "time-slot p-3 border rounded-lg text-center transition-all",
                slot.available ? (
                  selectedTime === slot.time
                    ? "border-primary bg-primary bg-opacity-5 text-primary"
                    : "border-neutral-200 hover:border-primary hover:text-primary"
                ) : "border-neutral-200 opacity-50 cursor-not-allowed"
              )}
              disabled={!slot.available}
              onClick={() => slot.available && onSelectTime(slot.time)}
            >
              <span className={cn(
                "font-medium",
                selectedTime === slot.time && "text-primary"
              )}>
                {slot.time}
              </span>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default TimeSelection;
