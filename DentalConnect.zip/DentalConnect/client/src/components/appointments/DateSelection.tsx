import { useState, useEffect } from "react";
import { format, addMonths, subMonths, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameMonth, isSameDay, isToday, isAfter } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface DateSelectionProps {
  selectedDate: Date | null;
  onSelectDate: (date: Date) => void;
}

const DateSelection = ({ selectedDate, onSelectDate }: DateSelectionProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const renderCalendarDays = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);
    
    const rows = [];
    let days = [];
    let day = startDate;
    
    // Header with day names
    const dayNames = ["S", "M", "T", "W", "T", "F", "S"];
    
    // Calendar days
    while (day <= endDate) {
      for (let i = 0; i < 7; i++) {
        const cloneDay = day;
        const isCurrentMonth = isSameMonth(day, monthStart);
        const isSelected = selectedDate ? isSameDay(day, selectedDate) : false;
        const isCurrentDay = isToday(day);
        const isSelectable = isAfter(day, new Date()) || isToday(day);
        
        days.push(
          <button
            key={day.toString()}
            className={cn(
              "calendar-day flex items-center justify-center rounded-full",
              !isCurrentMonth && "text-neutral-300",
              isCurrentDay && !isSelected && "text-primary font-semibold",
              isSelected && "bg-primary text-white",
              !isSelectable && "opacity-50 cursor-not-allowed"
            )}
            onClick={() => isSelectable && onSelectDate(cloneDay)}
            disabled={!isSelectable || !isCurrentMonth}
          >
            {format(day, "d")}
          </button>
        );
        day = addDays(day, 1);
      }
      rows.push(
        <div key={day.toString()} className="grid grid-cols-7 gap-1">
          {days}
        </div>
      );
      days = [];
    }
    
    return (
      <>
        <div className="grid grid-cols-7 gap-1 text-center mb-2">
          {dayNames.map((day) => (
            <span key={day} className="text-xs text-neutral-500">
              {day}
            </span>
          ))}
        </div>
        {rows}
      </>
    );
  };
  
  const previousMonth = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };
  
  const nextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };
  
  return (
    <Card>
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-3">Select Date</h2>
        
        {/* Month Navigation */}
        <div className="flex justify-between items-center mb-4">
          <Button 
            variant="ghost" 
            size="icon" 
            className="p-2 rounded-full hover:bg-neutral-100" 
            onClick={previousMonth}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <span className="font-medium">{format(currentDate, "MMMM yyyy")}</span>
          <Button 
            variant="ghost" 
            size="icon" 
            className="p-2 rounded-full hover:bg-neutral-100" 
            onClick={nextMonth}
          >
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Calendar */}
        {renderCalendarDays()}
      </CardContent>
    </Card>
  );
};

export default DateSelection;
