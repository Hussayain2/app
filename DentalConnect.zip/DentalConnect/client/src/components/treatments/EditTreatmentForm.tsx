import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import PageContainer from "@/components/layout/PageContainer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { BriefcaseMedical, Calendar, DollarSign, FileText, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Treatment } from "@shared/schema";

interface EditTreatmentFormProps {
  treatment: Treatment;
  onClose: () => void;
}

// Create form schema based on treatment fields
const formSchema = z.object({
  treatmentDate: z.string().nonempty("Treatment date is required"),
  treatmentType: z.string().nonempty("Treatment type is required"),
  description: z.string().nonempty("Description is required"),
  dentistName: z.string().optional(),
  notes: z.string().optional(),
  cost: z.string().min(1, "Cost is required"),
  isPaid: z.boolean().default(false),
});

type FormValues = z.infer<typeof formSchema>;

export default function EditTreatmentForm({ treatment, onClose }: EditTreatmentFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      treatmentDate: treatment.treatmentDate.toString().substring(0, 10), // Format as YYYY-MM-DD
      treatmentType: treatment.treatmentType,
      description: treatment.description,
      dentistName: treatment.dentistName || "",
      notes: treatment.notes || "",
      cost: treatment.cost.toString(),
      isPaid: treatment.isPaid || false,
    },
  });
  
  const updateMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      return await apiRequest("PUT", `/api/treatments/${treatment.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/treatments"] });
      toast({
        title: "Treatment updated",
        description: "The treatment record has been updated successfully.",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update treatment record. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: FormValues) => {
    updateMutation.mutate(data);
  };

  return (
    <PageContainer title="Edit Treatment">
      <div className="max-w-3xl mx-auto">
        {/* Back button */}
        <Button 
          variant="ghost" 
          className="mb-4" 
          onClick={onClose}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Treatment Details
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle>Edit Treatment Record</CardTitle>
          </CardHeader>
          
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Treatment Date */}
                  <FormField
                    control={form.control}
                    name="treatmentDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2 text-primary" />
                          Treatment Date
                        </FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Treatment Type */}
                  <FormField
                    control={form.control}
                    name="treatmentType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center">
                          <BriefcaseMedical className="h-4 w-4 mr-2 text-primary" />
                          Treatment Type
                        </FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select treatment type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="preventive">Preventive</SelectItem>
                            <SelectItem value="restorative">Restorative</SelectItem>
                            <SelectItem value="cosmetic">Cosmetic</SelectItem>
                            <SelectItem value="surgical">Surgical</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Description */}
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem className="col-span-full">
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="E.g., Dental cleaning, Cavity filling, etc." 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Dentist Name */}
                  <FormField
                    control={form.control}
                    name="dentistName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Dentist Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="E.g., Dr. Williams" 
                            {...field} 
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Cost */}
                  <FormField
                    control={form.control}
                    name="cost"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-2 text-primary" />
                          Cost
                        </FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">$</span>
                            <Input 
                              type="number" 
                              step="0.01" 
                              min="0" 
                              placeholder="0.00" 
                              className="pl-8"
                              {...field} 
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Paid Status */}
                  <FormField
                    control={form.control}
                    name="isPaid"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Payment Status</FormLabel>
                          <FormDescription>
                            Mark this treatment as paid
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  {/* Notes */}
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem className="col-span-full">
                        <FormLabel className="flex items-center">
                          <FileText className="h-4 w-4 mr-2 text-primary" />
                          Notes
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Any additional notes or comments about the treatment" 
                            {...field} 
                            value={field.value || ""}
                            className="min-h-[120px]"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <CardFooter className="flex justify-end gap-3 px-0 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={onClose}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={updateMutation.isPending}
                  >
                    {updateMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                </CardFooter>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
}