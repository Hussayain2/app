import { useEffect, useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { StarIcon, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// SVG profile images for clients
const ClientRobertSvg = () => (
  <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="35" r="25" fill="#D8E2DC" />
    <path d="M50,70 Q65,65 65,85 Q65,95 50,95 Q35,95 35,85 Q35,65 50,70" fill="#D8E2DC" />
    <path d="M35,42 Q50,50 65,42" fill="none" stroke="#333" strokeWidth="1.5" />
    <circle cx="40" cy="30" r="3" fill="#333" />
    <circle cx="60" cy="30" r="3" fill="#333" />
    <circle cx="50" cy="10" r="10" fill="#666" />
    <rect x="30" y="10" width="40" height="15" fill="#666" />
    <path d="M20,20 L35,25 L35,15 Z" fill="#666" />
    <path d="M80,20 L65,25 L65,15 Z" fill="#666" />
  </svg>
);

const ClientJenniferSvg = () => (
  <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="35" r="25" fill="#FFE5D9" />
    <path d="M50,70 Q65,65 65,85 Q65,95 50,95 Q35,95 35,85 Q35,65 50,70" fill="#FFE5D9" />
    <path d="M40,38 Q50,45 60,38" fill="none" stroke="#333" strokeWidth="1.5" />
    <circle cx="40" cy="30" r="3" fill="#333" />
    <circle cx="60" cy="30" r="3" fill="#333" />
    <path d="M25,20 Q50,0 75,20" fill="none" stroke="#D9B99B" strokeWidth="6" />
    <path d="M25,25 Q50,10 75,25" fill="none" stroke="#D9B99B" strokeWidth="6" />
    <path d="M25,30 Q50,15 75,30" fill="none" stroke="#D9B99B" strokeWidth="6" />
    <path d="M25,35 Q50,20 75,35" fill="none" stroke="#D9B99B" strokeWidth="4" />
  </svg>
);

const ClientDavidSvg = () => (
  <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="35" r="25" fill="#E8E8E8" />
    <path d="M50,70 Q65,65 65,85 Q65,95 50,95 Q35,95 35,85 Q35,65 50,70" fill="#E8E8E8" />
    <path d="M35,40 Q50,48 65,40" fill="none" stroke="#333" strokeWidth="1.5" />
    <circle cx="40" cy="30" r="3" fill="#333" />
    <circle cx="60" cy="30" r="3" fill="#333" />
    <rect x="30" y="15" width="40" height="2" fill="#333" />
    <path d="M25,15 C25,5 75,5 75,15" fill="none" stroke="#444" strokeWidth="4" />
    <path d="M30,10 L30,20" stroke="#444" strokeWidth="2" />
    <path d="M70,10 L70,20" stroke="#444" strokeWidth="2" />
  </svg>
);

// Star rating component
const StarRating = ({ rating }: { rating: number }) => {
  return (
    <div className="flex space-x-1">
      {[...Array(5)].map((_, i) => (
        <StarIcon 
          key={i} 
          className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
        />
      ))}
    </div>
  );
};

const ClientTestimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const testimonials = [
    {
      name: "Robert Thompson",
      review: "I was nervous about my dental procedure, but Dr. Williams made the experience comfortable and painless. Highly recommend!",
      rating: 5,
      date: "March 10, 2025",
      SvgImage: ClientRobertSvg,
      imageFallback: "RT"
    },
    {
      name: "Jennifer Davis",
      review: "The entire team is friendly and professional. My children actually look forward to their dental checkups now!",
      rating: 5,
      date: "February 22, 2025",
      SvgImage: ClientJenniferSvg,
      imageFallback: "JD"
    },
    {
      name: "David Wilson",
      review: "I've been coming to this clinic for years. The loyalty program is a great bonus on top of the excellent dental care.",
      rating: 4,
      date: "January 15, 2025",
      SvgImage: ClientDavidSvg,
      imageFallback: "DW"
    }
  ];

  const nextTestimonial = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
    setTimeout(() => setIsAnimating(false), 500);
  };

  const prevTestimonial = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
    setTimeout(() => setIsAnimating(false), 500);
  };

  // Auto-rotate testimonials
  useEffect(() => {
    intervalRef.current = setInterval(() => {
      nextTestimonial();
    }, 7000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  // Pause auto-rotation when user interacts
  const pauseAutoRotation = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
  };

  // Resume auto-rotation after user interaction
  const resumeAutoRotation = () => {
    pauseAutoRotation();
    intervalRef.current = setInterval(() => {
      nextTestimonial();
    }, 7000);
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <div className="mb-8 relative">
      <h2 className="text-xl font-bold mb-4 text-gray-900">What Our Patients Say</h2>
      
      <Card className="border-0 overflow-hidden shadow-[0_20px_70px_-25px_rgba(0,0,0,0.1)] bg-gradient-to-tr from-white to-gray-50">
        <CardContent className="relative p-0">
          {/* Decorative background elements */}
          <div className="absolute top-0 left-0 w-full h-16 bg-gradient-to-r from-primary/10 to-blue-50 opacity-60"></div>
          <div className="absolute bottom-0 right-0 w-48 h-48 rounded-full bg-gradient-to-tr from-primary/5 to-white blur-2xl"></div>
          <div className="absolute top-6 left-6 text-primary/20">
            <Quote className="h-20 w-20" />
          </div>
          
          <div 
            className={cn(
              "p-6 pt-12 transition-opacity duration-500",
              isAnimating ? "opacity-0" : "opacity-100"
            )}
          >
            <div className="flex flex-col sm:flex-row items-center gap-6 z-10 relative">
              {/* Avatar with shadow and border */}
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-tr from-blue-500 to-primary rounded-full blur-md opacity-20"></div>
                <Avatar className="h-20 w-20 border-4 border-white shadow-lg relative">
                  <currentTestimonial.SvgImage />
                  <AvatarFallback>
                    {currentTestimonial.imageFallback}
                  </AvatarFallback>
                </Avatar>
              </div>
              
              {/* Testimonial content */}
              <div className="flex-1 text-center sm:text-left">
                <p className="text-gray-700 italic relative text-lg mb-6">
                  "{currentTestimonial.review}"
                </p>
                
                <div className="mt-4">
                  <h3 className="font-bold text-gray-900">{currentTestimonial.name}</h3>
                  <div className="flex items-center justify-center sm:justify-start gap-2 mt-1">
                    <StarRating rating={currentTestimonial.rating} />
                    <span className="text-xs text-gray-500">
                      {currentTestimonial.date}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Navigation dots */}
          <div className="flex justify-center gap-2 py-4">
            {testimonials.map((_, index) => (
              <button 
                key={index}
                onClick={() => {
                  pauseAutoRotation();
                  setCurrentIndex(index);
                  resumeAutoRotation();
                }}
                className={cn(
                  "w-2 h-2 rounded-full transition-all duration-300",
                  currentIndex === index 
                    ? "bg-primary w-6" 
                    : "bg-gray-300 hover:bg-gray-400"
                )}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
          
          {/* Navigation buttons */}
          <div className="absolute top-1/2 left-0 right-0 flex justify-between px-2 transform -translate-y-1/2 z-20">
            <Button
              variant="ghost"
              size="icon"
              className="h-10 w-10 rounded-full bg-white/80 hover:bg-white shadow-md"
              onClick={() => {
                pauseAutoRotation();
                prevTestimonial();
                resumeAutoRotation();
              }}
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="h-6 w-6 text-primary" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-10 w-10 rounded-full bg-white/80 hover:bg-white shadow-md"
              onClick={() => {
                pauseAutoRotation();
                nextTestimonial();
                resumeAutoRotation();
              }}
              aria-label="Next testimonial"
            >
              <ChevronRight className="h-6 w-6 text-primary" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClientTestimonials;