import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useUser } from "@/context/UserContext";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Reward } from "@shared/schema";

const RewardItem = ({ reward }: { reward: Reward }) => {
  const { user, setUser } = useUser();
  const { toast } = useToast();
  const [isRedeeming, setIsRedeeming] = useState(false);
  
  const currentPoints = user?.loyaltyPoints || 0;
  const hasEnoughPoints = currentPoints >= reward.pointsCost;
  const pointsNeeded = reward.pointsCost - currentPoints;
  
  const handleRedeem = async () => {
    if (!hasEnoughPoints) return;
    
    setIsRedeeming(true);
    try {
      const response = await apiRequest("POST", `/api/rewards/${reward.id}/redeem`, {});
      const data = await response.json();
      
      // Update user with new points
      if (data.user) {
        setUser(data.user);
      }
      
      toast({
        title: "Reward Redeemed!",
        description: `You've successfully redeemed ${reward.name}. You can collect it at your next visit.`,
      });
      
      // Refresh rewards list
      queryClient.invalidateQueries({ queryKey: ["/api/rewards"] });
    } catch (error) {
      toast({
        title: "Redemption Failed",
        description: "Failed to redeem reward. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsRedeeming(false);
    }
  };
  
  return (
    <div className="p-4 border border-neutral-200 rounded-lg">
      <div className="flex justify-between items-center">
        <h3 className="font-medium">{reward.name}</h3>
        <span className="text-amber-500 font-semibold">{reward.pointsCost} pts</span>
      </div>
      <p className="text-sm text-neutral-600 mt-1">{reward.description}</p>
      <Button
        variant={hasEnoughPoints ? "default" : "outline"}
        size="sm"
        className={`mt-3 ${!hasEnoughPoints ? "opacity-70" : ""}`}
        disabled={!hasEnoughPoints || isRedeeming}
        onClick={handleRedeem}
      >
        {isRedeeming 
          ? "Redeeming..." 
          : hasEnoughPoints 
            ? "Redeem Reward" 
            : `Need ${pointsNeeded} more points`
        }
      </Button>
    </div>
  );
};

const AvailableRewards = () => {
  const { data: rewards = [], isLoading } = useQuery<Reward[]>({
    queryKey: ["/api/rewards"],
  });
  
  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-4">
          <h2 className="text-lg font-semibold mb-3">Available Rewards</h2>
          <div className="space-y-3">
            <div className="p-4 border border-neutral-200 rounded-lg h-24 animate-pulse" />
            <div className="p-4 border border-neutral-200 rounded-lg h-24 animate-pulse" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-3">Available Rewards</h2>
        
        <div className="space-y-3">
          {rewards.map((reward) => (
            <RewardItem key={reward.id} reward={reward} />
          ))}
          
          {rewards.length === 0 && (
            <div className="p-4 text-center text-neutral-600">
              No rewards available at the moment.
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default AvailableRewards;
