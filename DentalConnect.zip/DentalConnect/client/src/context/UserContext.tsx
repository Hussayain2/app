import React, { createContext, useContext, useState, useEffect } from "react";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface UserContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  isLoading: boolean;
  error: string | null;
}

const UserContext = createContext<UserContextType>({
  user: null,
  setUser: () => {},
  isLoading: false,
  error: null,
});

export const useUser = () => useContext(UserContext);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await fetch("/api/auth/me", {
          credentials: "include",
        });

        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
        } else {
          // For demo purposes, create a mock user if no user is logged in
          const mockUserData = {
            id: 1,
            username: "sarahj",
            firstName: "Sarah",
            lastName: "Johnson",
            email: "sarah.j@example.com",
            phone: "(555) 123-4567",
            loyaltyPoints: 350,
            referralCode: "SARAHREF123",
            address: "123 Main Street, Apt 4B\nNew York, NY 10001"
          };
          
          // Create the user in the backend
          try {
            const createResponse = await apiRequest("POST", "/api/auth/register", {
              ...mockUserData,
              password: "password123"
            });
            
            if (createResponse.ok) {
              const newUser = await createResponse.json();
              setUser(newUser);
              
              // Create medical history
              await apiRequest("POST", "/api/medical-history", {
                userId: newUser.id,
                allergies: "Penicillin, Latex",
                medications: "Lisinopril, Metformin",
                conditions: "Hypertension, Type 2 Diabetes"
              });
              
              // Create a welcome notification
              await apiRequest("POST", "/api/notifications", {
                userId: newUser.id,
                title: "Welcome to DentalConnect",
                message: "Thank you for joining our dental clinic app. Book your first appointment to earn loyalty points!",
                type: "general"
              });
            }
          } catch (createError) {
            // If user already exists, try to log in
            try {
              const loginResponse = await apiRequest("POST", "/api/auth/login", {
                username: mockUserData.username,
                password: "password123"
              });
              
              if (loginResponse.ok) {
                const existingUser = await loginResponse.json();
                setUser(existingUser);
              }
            } catch (loginError) {
              console.error("Error during auto-login:", loginError);
            }
          }
        }
      } catch (error) {
        setError("Failed to fetch user data");
        toast({
          title: "Error",
          description: "Failed to load user data. Please refresh the page.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchUser();
  }, [toast]);

  return (
    <UserContext.Provider value={{ user, setUser, isLoading, error }}>
      {children}
    </UserContext.Provider>
  );
};
