import PageContainer from "@/components/layout/PageContainer";
import WelcomeSection from "@/components/home/WelcomeSection";
import UpcomingAppointment from "@/components/home/UpcomingAppointment";
import QuickActions from "@/components/home/QuickActions";
import Notifications from "@/components/home/Notifications";
import ClinicTeam from "@/components/home/ClinicTeam";
import ClientTestimonials from "@/components/home/ClientTestimonials";

const HomePage = () => {
  return (
    <PageContainer>
      <WelcomeSection />
      <UpcomingAppointment />
      <QuickActions />
      <ClinicTeam />
      <ClientTestimonials />
      <Notifications />
    </PageContainer>
  );
};

export default HomePage;
