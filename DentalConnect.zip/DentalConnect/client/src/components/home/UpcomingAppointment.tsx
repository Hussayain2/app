import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { format, addDays } from "date-fns";
import { Calendar, X, Clock, MapPin, CheckCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Appointment } from "@shared/schema";

// SVG of a dental chair
const DentalChairSvg = () => (
  <svg viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-primary opacity-10">
    <path d="M45,15 L45,40 Q45,45 40,45 L20,45 Q15,45 15,40 L15,15" stroke="currentColor" strokeWidth="4" fill="none" />
    <rect x="10" y="45" width="40" height="5" rx="2" fill="currentColor" />
    <rect x="22" y="10" width="16" height="5" rx="2" fill="currentColor" />
    <path d="M30,15 L30,25" stroke="currentColor" strokeWidth="2" fill="none" />
    <rect x="25" y="25" width="10" height="15" rx="2" fill="currentColor" />
  </svg>
);

const UpcomingAppointment = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const { data: appointments = [], isLoading } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments"],
  });
  
  // Use real appointment if available, otherwise default to null
  const nextAppointment = appointments.length > 0 
    ? appointments
        .filter(app => new Date(app.date) >= new Date())
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0]
    : null;
  
  const handleReschedule = () => {
    navigate("/appointments");
  };
  
  const handleCancel = async () => {
    if (!nextAppointment) return;
    
    try {
      await apiRequest("DELETE", `/api/appointments/${nextAppointment.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Appointment Cancelled",
        description: "Your appointment has been successfully cancelled.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to cancel appointment. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // If loading, show skeleton
  if (isLoading) {
    return (
      <Card className="overflow-hidden border-none shadow-lg">
        <CardContent className="p-0">
          <div className="bg-gradient-to-r from-primary to-primary/80 p-4 text-white">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold">Your Next Appointment</h2>
              <Button
                variant="ghost"
                className="text-white hover:text-white hover:bg-white/20 text-sm font-medium p-2"
                onClick={() => navigate("/appointments")}
              >
                View all
              </Button>
            </div>
          </div>
          <div className="p-6">
            <div className="h-24 bg-neutral-100 animate-pulse rounded-lg"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // If no appointments found, show example or prompt to book
  if (!nextAppointment) {
    // Show example appointment card with booking prompt
    const exampleDate = addDays(new Date(), 3);
    
    return (
      <Card className="overflow-hidden border-none shadow-lg mb-6">
        <CardContent className="p-0">
          <div className="bg-gradient-to-r from-primary to-primary/80 p-4 text-white">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold">Your Next Appointment</h2>
              <Button
                variant="ghost"
                className="text-white hover:text-white hover:bg-white/20 text-sm font-medium p-2"
                onClick={() => navigate("/appointments")}
              >
                Book now
              </Button>
            </div>
          </div>
          
          <div className="p-6 relative">
            {/* Background decoration */}
            <div className="absolute right-5 bottom-5 opacity-10">
              <DentalChairSvg />
            </div>
            
            <div className="text-center py-4">
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Upcoming Appointments</h3>
              <p className="text-gray-600 mb-6">It's time for your regular dental check-up!</p>
              
              <Button 
                variant="default" 
                className="rounded-full"
                onClick={() => navigate("/appointments")}
                size="lg"
              >
                <Calendar className="h-5 w-5 mr-2" />
                Schedule Now
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Format date for real appointment
  const appointmentDate = new Date(nextAppointment.date);
  const month = format(appointmentDate, "MMM").toUpperCase();
  const day = format(appointmentDate, "d");
  const weekday = format(appointmentDate, "EEEE");
  const formattedDate = format(appointmentDate, "MMMM d, yyyy");
  
  return (
    <Card className="overflow-hidden border-none shadow-lg mb-6">
      <CardContent className="p-0">
        <div className="bg-gradient-to-r from-primary to-primary/80 p-4 text-white">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold">Your Next Appointment</h2>
            <Button
              variant="ghost"
              className="text-white hover:text-white hover:bg-white/20 text-sm font-medium p-2"
              onClick={() => navigate("/appointments")}
            >
              View all
            </Button>
          </div>
        </div>
        
        <div className="p-6 relative">
          {/* Background decoration */}
          <div className="absolute right-5 bottom-5 opacity-10">
            <DentalChairSvg />
          </div>
          
          <div className="flex items-start gap-5">
            {/* Date box */}
            <div className="bg-primary/10 rounded-2xl w-20 h-24 flex flex-col items-center justify-center text-primary border border-primary/20 shadow-sm">
              <span className="text-sm font-medium">{month}</span>
              <span className="text-3xl font-bold">{day}</span>
              <span className="text-xs mt-1">{weekday}</span>
            </div>
            
            {/* Appointment details */}
            <div className="flex-1 space-y-3">
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <h3 className="font-semibold text-lg text-primary">{nextAppointment.type}</h3>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center text-neutral-600">
                  <Clock className="h-4 w-4 mr-2" /> 
                  <span className="text-sm">{nextAppointment.time} • {formattedDate}</span>
                </div>
                
                <div className="flex items-center text-neutral-600">
                  <MapPin className="h-4 w-4 mr-2" /> 
                  <span className="text-sm">Bright Smile Dental Clinic, Suite 101</span>
                </div>
                
                <div className="flex items-center font-medium">
                  <span className="text-sm">With {nextAppointment.dentistName || "Dr. Williams"}</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Action buttons */}
          <div className="flex gap-3 mt-6 justify-end">
            <Button 
              variant="outline" 
              className="rounded-full border-primary/30 hover:bg-primary/5"
              onClick={handleReschedule}
              size="sm"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Reschedule
            </Button>
            <Button 
              variant="outline" 
              className="rounded-full border-red-300 text-red-500 hover:bg-red-50 hover:text-red-600"
              onClick={handleCancel}
              size="sm"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default UpcomingAppointment;
