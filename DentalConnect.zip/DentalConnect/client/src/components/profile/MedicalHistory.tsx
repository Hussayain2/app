import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useUser } from "@/context/UserContext";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { MedicalHistory as MedicalHistoryType } from "@shared/schema";

const medicalHistoryFormSchema = z.object({
  allergies: z.string().optional(),
  medications: z.string().optional(),
  conditions: z.string().optional(),
});

type MedicalHistoryFormValues = z.infer<typeof medicalHistoryFormSchema>;

const MedicalHistory = () => {
  const { user } = useUser();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { data: medicalHistory, isLoading } = useQuery<MedicalHistoryType>({
    queryKey: ["/api/medical-history"],
    enabled: !!user,
  });
  
  const form = useForm<MedicalHistoryFormValues>({
    resolver: zodResolver(medicalHistoryFormSchema),
    defaultValues: {
      allergies: medicalHistory?.allergies || "",
      medications: medicalHistory?.medications || "",
      conditions: medicalHistory?.conditions || "",
    },
  });
  
  // Update form when data is loaded
  useState(() => {
    if (medicalHistory) {
      form.reset({
        allergies: medicalHistory.allergies || "",
        medications: medicalHistory.medications || "",
        conditions: medicalHistory.conditions || "",
      });
    }
  });
  
  const onSubmit = async (data: MedicalHistoryFormValues) => {
    if (!user) return;
    
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/medical-history", data);
      
      queryClient.invalidateQueries({ queryKey: ["/api/medical-history"] });
      setIsEditing(false);
      
      toast({
        title: "Medical History Updated",
        description: "Your medical history has been updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update medical history. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Medical History</h2>
          </div>
          <div className="space-y-3">
            <div className="p-3 bg-neutral-100 rounded-lg h-16 animate-pulse" />
            <div className="p-3 bg-neutral-100 rounded-lg h-16 animate-pulse" />
            <div className="p-3 bg-neutral-100 rounded-lg h-16 animate-pulse" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <>
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Medical History</h2>
            <Button
              variant="link"
              className="text-primary text-sm font-medium p-0"
              onClick={() => setIsEditing(true)}
            >
              Update
            </Button>
          </div>
          
          <div className="space-y-3">
            <div className="p-3 bg-neutral-100 rounded-lg">
              <h3 className="font-medium">Allergies</h3>
              <p className="text-sm text-neutral-600 mt-1">
                {medicalHistory?.allergies || "None reported"}
              </p>
            </div>
            
            <div className="p-3 bg-neutral-100 rounded-lg">
              <h3 className="font-medium">Current Medications</h3>
              <p className="text-sm text-neutral-600 mt-1">
                {medicalHistory?.medications || "None reported"}
              </p>
            </div>
            
            <div className="p-3 bg-neutral-100 rounded-lg">
              <h3 className="font-medium">Medical Conditions</h3>
              <p className="text-sm text-neutral-600 mt-1">
                {medicalHistory?.conditions || "None reported"}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Medical History</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="allergies"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Allergies</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="List any allergies, or type 'None' if not applicable"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="medications"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Medications</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="List any medications you're currently taking"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="conditions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Medical Conditions</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="List any medical conditions you have"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditing(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Saving..." : "Save Changes"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default MedicalHistory;
