import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import AppointmentsPage from "@/pages/AppointmentsPage";
import ContactPage from "@/pages/ContactPage";
import RewardsPage from "@/pages/RewardsPage";
import ProfilePage from "@/pages/ProfilePage";
import TreatmentHistoryPage from "@/pages/TreatmentHistoryPage";
import BottomNavigation from "@/components/layout/BottomNavigation";
import { UserProvider } from "@/context/UserContext";

function App() {
  const [location] = useLocation();
  const [showNavigation, setShowNavigation] = useState(true);

  useEffect(() => {
    // Hide navigation on specific routes if needed
    // For now, show on all routes
    setShowNavigation(true);
  }, [location]);

  return (
    <QueryClientProvider client={queryClient}>
      <UserProvider>
        <div className="flex flex-col min-h-screen bg-neutral-50">
          <Switch>
            <Route path="/" component={HomePage} />
            <Route path="/appointments" component={AppointmentsPage} />
            <Route path="/contact" component={ContactPage} />
            <Route path="/rewards" component={RewardsPage} />
            <Route path="/profile" component={ProfilePage} />
            <Route path="/treatments" component={TreatmentHistoryPage} />
            <Route component={NotFound} />
          </Switch>
          
          {showNavigation && <BottomNavigation />}
        </div>
        <Toaster />
      </UserProvider>
    </QueryClientProvider>
  );
}

export default App;
