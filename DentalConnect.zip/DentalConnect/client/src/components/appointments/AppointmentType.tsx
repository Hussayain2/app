import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Clock, Sparkles, Stethoscope, Smile, ShieldCheck, BadgeCheck } from "lucide-react";
import { cn } from "@/lib/utils";

interface AppointmentTypeOption {
  id: string;
  name: string;
  description: string;
  duration: string;
  price?: string;
  icon: React.ReactNode;
  category: "general" | "cosmetic" | "specialized";
}

interface AppointmentTypeProps {
  selectedType: string;
  onSelectType: (type: string) => void;
  onConfirm: () => void;
  isSubmitting: boolean;
  isComplete: boolean;
}

// SVG icons for dental services
const ToothBrushIcon = () => (
  <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M3,21V17C3,15.9 3.9,15 5,15H19C20.1,15 21,15.9 21,17V21" stroke="currentColor" strokeWidth="2"/>
    <path d="M12,15V3M8,7H16M8,11H16" stroke="currentColor" strokeWidth="2"/>
  </svg>
);

const TeethWhiteningIcon = () => (
  <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12,2C13.1,2 14,2.9 14,4C14,5.1 13.1,6 12,6C10.9,6 10,5.1 10,4C10,2.9 10.9,2 12,2Z" />
    <path d="M10,8V20C10,21.1 10.9,22 12,22C13.1,22 14,21.1 14,20V8" />
    <path d="M6,10L18,10" />
  </svg>
);

const RootCanalIcon = () => (
  <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12,2C14.21,2 16,3.79 16,6C16,7.5 15.2,8.77 14,9.46V14L13,15L12,14L11,15L10,14V9.46C8.8,8.77 8,7.5 8,6C8,3.79 9.79,2 12,2Z" />
    <path d="M12,22L9,19H15L12,22Z" />
  </svg>
);

const BracesIcon = () => (
  <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M8,5H5A2,2 0 0,0 3,7V10A2,2 0 0,0 5,12H8M16,5H19A2,2 0 0,1 21,7V10A2,2 0 0,1 19,12H16M3,14V17A2,2 0 0,0 5,19H8M16,19H19A2,2 0 0,0 21,17V14" />
    <path d="M7,10H17M7,14H17" />
  </svg>
);

const AppointmentType = ({ 
  selectedType, 
  onSelectType, 
  onConfirm, 
  isSubmitting,
  isComplete
}: AppointmentTypeProps) => {
  const appointmentTypes: AppointmentTypeOption[] = [
    // General dentistry
    {
      id: "regular-checkup",
      name: "Regular Checkup",
      description: "Comprehensive oral examination and consultation",
      duration: "30 min",
      price: "$50",
      icon: <Stethoscope className="w-6 h-6" />,
      category: "general"
    },
    {
      id: "cleaning",
      name: "Teeth Cleaning",
      description: "Professional cleaning to remove plaque and tartar",
      duration: "45 min",
      price: "$85",
      icon: <ToothBrushIcon />,
      category: "general"
    },
    {
      id: "xray",
      name: "X-Ray & Assessment",
      description: "Comprehensive X-rays and dental evaluation",
      duration: "40 min",
      price: "$75",
      icon: <ShieldCheck className="w-6 h-6" />,
      category: "general"
    },
    // Cosmetic dentistry
    {
      id: "whitening",
      name: "Teeth Whitening",
      description: "Professional whitening for a brighter smile",
      duration: "60 min",
      price: "$200",
      icon: <TeethWhiteningIcon />,
      category: "cosmetic"
    },
    {
      id: "veneers-consultation",
      name: "Veneers Consultation",
      description: "Discuss options for porcelain veneers",
      duration: "45 min",
      price: "$100",
      icon: <Smile className="w-6 h-6" />,
      category: "cosmetic"
    },
    // Specialized treatments
    {
      id: "root-canal",
      name: "Root Canal Consultation",
      description: "Evaluation for root canal treatment",
      duration: "45 min",
      price: "$90",
      icon: <RootCanalIcon />,
      category: "specialized"
    },
    {
      id: "orthodontic-consult",
      name: "Orthodontic Consultation",
      description: "Assessment for braces or clear aligners",
      duration: "50 min",
      price: "$110",
      icon: <BracesIcon />,
      category: "specialized"
    },
    {
      id: "emergency",
      name: "Emergency Care",
      description: "Immediate care for dental emergencies",
      duration: "Varies",
      price: "From $120",
      icon: <BadgeCheck className="w-6 h-6" />,
      category: "specialized"
    }
  ];
  
  return (
    <Card className="border-gray-200">
      <CardContent className="p-0">
        <div className="bg-primary/5 p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold">Select Treatment</h2>
          <p className="text-sm text-gray-600">Choose the type of dental service you need</p>
        </div>
        
        <div className="p-4">
          <Tabs defaultValue="general" className="mb-4">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="cosmetic">Cosmetic</TabsTrigger>
              <TabsTrigger value="specialized">Specialized</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general" className="mt-0">
              <h3 className="text-sm font-medium text-gray-500 mb-3">General Dental Care</h3>
              <RadioGroup 
                value={selectedType} 
                onValueChange={onSelectType}
                className="space-y-3"
              >
                {appointmentTypes
                  .filter(type => type.category === "general")
                  .map((type) => (
                    <div 
                      key={type.id} 
                      className={cn(
                        "flex items-start p-3 border border-gray-200 rounded-md transition-all hover:bg-gray-50",
                        selectedType === type.name && "border-primary bg-primary/5"
                      )}
                    >
                      <RadioGroupItem 
                        value={type.name} 
                        id={type.id} 
                        className="w-5 h-5 mt-1 text-primary"
                      />
                      <Label htmlFor={type.id} className="ml-3 flex flex-col cursor-pointer">
                        <span className="font-medium text-gray-900">{type.name}</span>
                        <p className="text-xs text-gray-500 mt-1">{type.description}</p>
                        <div className="flex items-center mt-2 text-xs text-gray-600 space-x-4">
                          <span className="flex items-center">
                            <Clock className="w-3 h-3 mr-1" /> {type.duration}
                          </span>
                          {type.price && (
                            <span>{type.price}</span>
                          )}
                        </div>
                      </Label>
                      <div className="ml-auto text-primary/70">
                        {type.icon}
                      </div>
                    </div>
                  ))}
              </RadioGroup>
            </TabsContent>
            
            <TabsContent value="cosmetic" className="mt-0">
              <h3 className="text-sm font-medium text-gray-500 mb-3">Cosmetic Treatments</h3>
              <RadioGroup 
                value={selectedType} 
                onValueChange={onSelectType}
                className="space-y-3"
              >
                {appointmentTypes
                  .filter(type => type.category === "cosmetic")
                  .map((type) => (
                    <div 
                      key={type.id} 
                      className={cn(
                        "flex items-start p-3 border border-gray-200 rounded-md transition-all hover:bg-gray-50",
                        selectedType === type.name && "border-primary bg-primary/5"
                      )}
                    >
                      <RadioGroupItem 
                        value={type.name} 
                        id={type.id} 
                        className="w-5 h-5 mt-1 text-primary"
                      />
                      <Label htmlFor={type.id} className="ml-3 flex flex-col cursor-pointer">
                        <span className="font-medium text-gray-900">{type.name}</span>
                        <p className="text-xs text-gray-500 mt-1">{type.description}</p>
                        <div className="flex items-center mt-2 text-xs text-gray-600 space-x-4">
                          <span className="flex items-center">
                            <Clock className="w-3 h-3 mr-1" /> {type.duration}
                          </span>
                          {type.price && (
                            <span>{type.price}</span>
                          )}
                        </div>
                      </Label>
                      <div className="ml-auto text-primary/70">
                        {type.icon}
                      </div>
                    </div>
                  ))}
              </RadioGroup>
            </TabsContent>
            
            <TabsContent value="specialized" className="mt-0">
              <h3 className="text-sm font-medium text-gray-500 mb-3">Specialized Services</h3>
              <RadioGroup 
                value={selectedType} 
                onValueChange={onSelectType}
                className="space-y-3"
              >
                {appointmentTypes
                  .filter(type => type.category === "specialized")
                  .map((type) => (
                    <div 
                      key={type.id} 
                      className={cn(
                        "flex items-start p-3 border border-gray-200 rounded-md transition-all hover:bg-gray-50",
                        selectedType === type.name && "border-primary bg-primary/5"
                      )}
                    >
                      <RadioGroupItem 
                        value={type.name} 
                        id={type.id} 
                        className="w-5 h-5 mt-1 text-primary"
                      />
                      <Label htmlFor={type.id} className="ml-3 flex flex-col cursor-pointer">
                        <span className="font-medium text-gray-900">{type.name}</span>
                        <p className="text-xs text-gray-500 mt-1">{type.description}</p>
                        <div className="flex items-center mt-2 text-xs text-gray-600 space-x-4">
                          <span className="flex items-center">
                            <Clock className="w-3 h-3 mr-1" /> {type.duration}
                          </span>
                          {type.price && (
                            <span>{type.price}</span>
                          )}
                        </div>
                      </Label>
                      <div className="ml-auto text-primary/70">
                        {type.icon}
                      </div>
                    </div>
                  ))}
              </RadioGroup>
            </TabsContent>
          </Tabs>
          
          <div className="mt-6">
            <Button 
              className="w-full py-3 shadow-md" 
              onClick={onConfirm} 
              disabled={!selectedType || isSubmitting || isComplete}
            >
              {isSubmitting 
                ? "Scheduling..." 
                : isComplete 
                  ? "Appointment Confirmed" 
                  : selectedType 
                    ? `Book ${selectedType}` 
                    : "Select a Treatment"}
              {!isSubmitting && !isComplete && <Calendar className="ml-2 h-4 w-4" />}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AppointmentType;
