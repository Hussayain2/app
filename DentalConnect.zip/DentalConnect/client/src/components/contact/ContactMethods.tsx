import { Phone, Mail, MessageSquare } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface ContactMethodsProps {
  onStartChat: () => void;
}

const ContactMethods = ({ onStartChat }: ContactMethodsProps) => {
  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        <h2 className="text-lg font-semibold">Contact Methods</h2>
        
        <a 
          href="tel:+11234567890" 
          className="flex items-center p-3 bg-primary bg-opacity-5 rounded-lg"
        >
          <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
            <Phone className="h-5 w-5 text-primary" />
          </div>
          <div className="ml-3">
            <span className="font-medium">Call Us</span>
            <p className="text-sm text-neutral-600">(123) 456-7890</p>
          </div>
        </a>
        
        <a 
          href="mailto:contact@dentalclinic.com" 
          className="flex items-center p-3 bg-primary bg-opacity-5 rounded-lg"
        >
          <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
            <Mail className="h-5 w-5 text-primary" />
          </div>
          <div className="ml-3">
            <span className="font-medium">Email Us</span>
            <p className="text-sm text-neutral-600">contact@dentalclinic.com</p>
          </div>
        </a>
        
        <button 
          className="flex items-center p-3 bg-primary bg-opacity-5 rounded-lg w-full text-left"
          onClick={onStartChat}
        >
          <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
            <MessageSquare className="h-5 w-5 text-primary" />
          </div>
          <div className="ml-3">
            <span className="font-medium">Chat with Us</span>
            <p className="text-sm text-neutral-600">Start a conversation</p>
          </div>
        </button>
      </CardContent>
    </Card>
  );
};

export default ContactMethods;
