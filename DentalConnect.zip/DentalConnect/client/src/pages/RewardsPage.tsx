import PageContainer from "@/components/layout/PageContainer";
import LoyaltyProgress from "@/components/rewards/LoyaltyProgress";
import AvailableRewards from "@/components/rewards/AvailableRewards";
import ReferralProgram from "@/components/rewards/ReferralProgram";

const RewardsPage = () => {
  return (
    <PageContainer title="Loyalty Program">
      <LoyaltyProgress />
      <AvailableRewards />
      <ReferralProgram />
    </PageContainer>
  );
};

export default RewardsPage;
