import { useState } from "react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import PageContainer from "@/components/layout/PageContainer";
import DateSelection from "@/components/appointments/DateSelection";
import TimeSelection from "@/components/appointments/TimeSelection";
import AppointmentType from "@/components/appointments/AppointmentType";

const AppointmentsPage = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  
  const handleConfirmAppointment = async () => {
    if (!selectedDate || !selectedTime || !selectedType) {
      toast({
        title: "Incomplete Information",
        description: "Please select a date, time, and appointment type.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const formattedDate = format(selectedDate, "yyyy-MM-dd");
      
      await apiRequest("POST", "/api/appointments", {
        date: formattedDate,
        time: selectedTime,
        type: selectedType,
        dentistName: "Dr. Williams", // Default doctor
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      
      setIsComplete(true);
      toast({
        title: "Appointment Confirmed",
        description: `Your appointment has been scheduled for ${format(selectedDate, "MMMM d")} at ${selectedTime}.`,
      });
      
      // Redirect to home after a short delay
      setTimeout(() => {
        navigate("/");
      }, 2000);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to schedule appointment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <PageContainer title="Book Appointment">
      <DateSelection 
        selectedDate={selectedDate} 
        onSelectDate={setSelectedDate} 
      />
      
      {selectedDate && (
        <TimeSelection 
          selectedDate={selectedDate} 
          selectedTime={selectedTime} 
          onSelectTime={setSelectedTime} 
        />
      )}
      
      {selectedDate && selectedTime && (
        <AppointmentType 
          selectedType={selectedType} 
          onSelectType={setSelectedType} 
          onConfirm={handleConfirmAppointment}
          isSubmitting={isSubmitting}
          isComplete={isComplete}
        />
      )}
    </PageContainer>
  );
};

export default AppointmentsPage;
