import { useUser } from "@/context/UserContext";

const WelcomeSection = () => {
  const { user } = useUser();
  
  return (
    <div className="flex items-center justify-between">
      <div>
        <h1 className="text-2xl font-semibold">{user?.firstName || "Welcome"}</h1>
        <p className="text-neutral-600">Welcome back!</p>
      </div>
      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white overflow-hidden">
        {user?.firstName ? (
          // Display user initial if no profile image
          <span className="text-lg font-semibold">
            {user.firstName.charAt(0)}
          </span>
        ) : (
          // Default avatar icon
          <span className="ri-user-line text-xl"></span>
        )}
      </div>
    </div>
  );
};

export default WelcomeSection;
