import { Link, useLocation } from "wouter";
import { Home, Calendar, MessageSquare, Award, User } from "lucide-react";
import { cn } from "@/lib/utils";

const BottomNavigation = () => {
  const [location] = useLocation();

  const tabs = [
    {
      name: "Home",
      icon: Home,
      path: "/",
    },
    {
      name: "Book",
      icon: Calendar,
      path: "/appointments",
    },
    {
      name: "Message",
      icon: MessageSquare,
      path: "/contact",
    },
    {
      name: "Rewards",
      icon: Award,
      path: "/rewards",
      notification: true,
    },
    {
      name: "Profile",
      icon: User,
      path: "/profile",
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white z-10 shadow-[0_-2px_10px_rgba(0,0,0,0.05)] flex justify-around items-center p-3">
      {tabs.map((tab) => {
        const isActive = location === tab.path;
        
        return (
          <Link 
            key={tab.name} 
            href={tab.path}
            className="flex flex-col items-center justify-center w-1/5"
          >
            <div className="relative">
              <tab.icon 
                className={cn(
                  "h-5 w-5", 
                  isActive ? "text-primary" : "text-neutral-500"
                )} 
              />
              {tab.notification && (
                <span className="absolute top-0 right-0 w-2 h-2 bg-error rounded-full" />
              )}
            </div>
            <span 
              className={cn(
                "text-xs mt-1", 
                isActive ? "text-primary font-medium" : "text-neutral-500"
              )}
            >
              {tab.name}
            </span>
          </Link>
        );
      })}
    </nav>
  );
};

export default BottomNavigation;
