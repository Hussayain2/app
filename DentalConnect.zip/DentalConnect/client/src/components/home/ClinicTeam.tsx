import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Stethoscope, Award, ThumbsUp } from "lucide-react";

// SVG profile images for team members
const DrEmilySvg = () => (
  <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="35" r="25" fill="#F4EBDB" />
    <path d="M50,70 Q65,65 65,85 Q65,95 50,95 Q35,95 35,85 Q35,65 50,70" fill="#F4EBDB" />
    <path d="M35,40 Q50,45 65,40" fill="none" stroke="#333" strokeWidth="1.5" />
    <circle cx="40" cy="30" r="3" fill="#333" />
    <circle cx="60" cy="30" r="3" fill="#333" />
    <path d="M25,25 Q35,15 50,15 Q65,15 75,25" fill="none" stroke="#5A3825" strokeWidth="6" />
    <path d="M20,40 Q35,60 50,40 Q65,60 80,40" fill="none" stroke="#5A3825" strokeWidth="6" />
  </svg>
);

const DrMichaelSvg = () => (
  <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="35" r="25" fill="#E6D7C3" />
    <path d="M50,70 Q65,65 65,85 Q65,95 50,95 Q35,95 35,85 Q35,65 50,70" fill="#E6D7C3" />
    <path d="M35,42 Q50,50 65,42" fill="none" stroke="#333" strokeWidth="1.5" />
    <circle cx="40" cy="30" r="3" fill="#333" />
    <circle cx="60" cy="30" r="3" fill="#333" />
    <rect x="25" y="10" width="50" height="5" fill="#333" />
    <path d="M15,15 Q50,-5 85,15" fill="none" stroke="#333" strokeWidth="6" />
    <path d="M30,10 L30,20" stroke="#333" strokeWidth="2" />
    <path d="M70,10 L70,20" stroke="#333" strokeWidth="2" />
  </svg>
);

const DrSarahSvg = () => (
  <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="35" r="25" fill="#F3D6E1" />
    <path d="M50,70 Q65,65 65,85 Q65,95 50,95 Q35,95 35,85 Q35,65 50,70" fill="#F3D6E1" />
    <path d="M35,40 Q50,45 65,40" fill="none" stroke="#333" strokeWidth="1.5" />
    <circle cx="40" cy="30" r="3" fill="#333" />
    <circle cx="60" cy="30" r="3" fill="#333" />
    <path d="M20,20 Q50,0 80,20" fill="none" stroke="#8B4513" strokeWidth="8" />
    <path d="M20,30 Q35,40 40,20" fill="none" stroke="#8B4513" strokeWidth="3" />
    <path d="M80,30 Q65,40 60,20" fill="none" stroke="#8B4513" strokeWidth="3" />
  </svg>
);

const ClinicTeam = () => {
  const teamMembers = [
    {
      name: "Dr. Emily Williams",
      role: "Lead Dentist",
      specialty: "Cosmetic Dentistry",
      experience: "15+ years",
      imageFallback: "EW",
      SvgImage: DrEmilySvg
    },
    {
      name: "Dr. Michael Chen",
      role: "Orthodontist",
      specialty: "Braces & Aligners",
      experience: "12+ years",
      imageFallback: "MC",
      SvgImage: DrMichaelSvg
    },
    {
      name: "Dr. Sarah Johnson",
      role: "Pediatric Dentist",
      specialty: "Children's Dental Care",
      experience: "10+ years",
      imageFallback: "SJ",
      SvgImage: DrSarahSvg
    }
  ];

  const expertiseAreas = [
    {
      title: "Professional Care",
      description: "Our team provides top-quality dental care using the latest techniques and technology.",
      icon: Stethoscope
    },
    {
      title: "Award-Winning Service",
      description: "Recognized for excellence in patient satisfaction and dental care outcomes.",
      icon: Award
    },
    {
      title: "Patient-First Approach",
      description: "We prioritize your comfort and ensure a stress-free dental experience.",
      icon: ThumbsUp
    }
  ];

  return (
    <div className="mb-6">
      <h2 className="text-lg font-semibold mb-3">Our Clinic Team</h2>
      
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex flex-col space-y-6">
            {teamMembers.map((member) => (
              <div key={member.name} className="flex items-center space-x-4">
                <Avatar className="h-16 w-16 border-2 border-primary">
                  <member.SvgImage />
                  <AvatarFallback className="bg-primary text-white">
                    {member.imageFallback}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-medium">{member.name}</h3>
                  <p className="text-sm text-neutral-600">{member.role} • {member.specialty}</p>
                  <p className="text-xs text-neutral-500">{member.experience} experience</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      <h2 className="text-lg font-semibold mb-3">Our Expertise</h2>
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 gap-4">
            {expertiseAreas.map((area) => (
              <div key={area.title} className="flex space-x-3">
                <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-full flex items-center justify-center flex-shrink-0">
                  <area.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">{area.title}</h3>
                  <p className="text-sm text-neutral-600">{area.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClinicTeam;