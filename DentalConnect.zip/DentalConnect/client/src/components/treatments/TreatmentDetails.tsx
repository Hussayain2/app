import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import PageContainer from "@/components/layout/PageContainer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Pencil, Trash2, ArrowLeft, Calendar, User, FileText, DollarSign } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { formatDate } from "@/lib/dates";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Treatment } from "@shared/schema";
import EditTreatmentForm from "./EditTreatmentForm";

interface TreatmentDetailsProps {
  treatment: Treatment;
  onClose: () => void;
}

export default function TreatmentDetails({ treatment, onClose }: TreatmentDetailsProps) {
  const [isEditing, setIsEditing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("DELETE", `/api/treatments/${treatment.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/treatments"] });
      toast({
        title: "Treatment deleted",
        description: "The treatment record has been deleted successfully.",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete treatment record. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isEditing) {
    return (
      <EditTreatmentForm 
        treatment={treatment} 
        onClose={() => setIsEditing(false)} 
      />
    );
  }

  // Format the treatment data for display
  const formattedDate = formatDate(treatment.treatmentDate);
  const treatmentTypeDisplay = {
    preventive: "Preventive Care",
    restorative: "Restorative Treatment",
    cosmetic: "Cosmetic Procedure",
    surgical: "Surgical Procedure"
  }[treatment.treatmentType] || treatment.treatmentType;

  return (
    <PageContainer title="Treatment Details">
      <div className="max-w-3xl mx-auto">
        {/* Back button */}
        <Button 
          variant="ghost" 
          className="mb-4" 
          onClick={onClose}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Treatment History
        </Button>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>{treatment.description}</CardTitle>
              <Badge 
                className="mt-2" 
                variant={
                  treatment.treatmentType === "preventive" ? "outline" :
                  treatment.treatmentType === "cosmetic" ? "secondary" :
                  treatment.treatmentType === "surgical" ? "destructive" : "default"
                }
              >
                {treatmentTypeDisplay}
              </Badge>
            </div>
            <div>
              <Badge variant={treatment.isPaid ? "success" : "outline"}>
                {treatment.isPaid ? "Paid" : "Unpaid"}
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start space-x-3">
                <Calendar className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <p className="font-medium">Treatment Date</p>
                  <p className="text-gray-600">{formattedDate}</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <User className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <p className="font-medium">Dentist</p>
                  <p className="text-gray-600">{treatment.dentistName || "Not specified"}</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <DollarSign className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <p className="font-medium">Cost</p>
                  <p className="text-gray-600">${parseFloat(treatment.cost).toFixed(2)}</p>
                </div>
              </div>
            </div>
            
            {treatment.notes && (
              <>
                <Separator />
                <div className="flex items-start space-x-3">
                  <FileText className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <p className="font-medium">Notes</p>
                    <p className="text-gray-600 whitespace-pre-line">{treatment.notes}</p>
                  </div>
                </div>
              </>
            )}
          </CardContent>
          
          <CardFooter className="justify-between">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setIsEditing(true)}
            >
              <Pencil className="h-4 w-4 mr-2" />
              Edit
            </Button>
            
            {/* Delete confirmation dialog */}
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the
                    treatment record from your history.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    onClick={() => deleteMutation.mutate()}
                    disabled={deleteMutation.isPending}
                  >
                    {deleteMutation.isPending ? "Deleting..." : "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardFooter>
        </Card>
      </div>
    </PageContainer>
  );
}