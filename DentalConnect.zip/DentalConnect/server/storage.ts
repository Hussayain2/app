import {
  users, User, InsertUser,
  appointments, Appointment, InsertAppointment,
  medicalHistories, MedicalHistory, InsertMedicalHistory,
  notifications, Notification, InsertNotification,
  messages, Message, InsertMessage,
  rewards, Reward, InsertReward,
  settings, Settings, InsertSettings,
  treatments, Treatment, InsertTreatment
} from "@shared/schema";
import { nanoid } from "nanoid";

// Extended storage interface with all required CRUD operations
export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  
  // Appointments
  getAppointment(id: number): Promise<Appointment | undefined>;
  getAppointmentsByUserId(userId: number): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointmentData: Partial<Appointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: number): Promise<boolean>;
  
  // Medical History
  getMedicalHistory(userId: number): Promise<MedicalHistory | undefined>;
  createMedicalHistory(medicalHistory: InsertMedicalHistory): Promise<MedicalHistory>;
  updateMedicalHistory(userId: number, medicalHistoryData: Partial<MedicalHistory>): Promise<MedicalHistory | undefined>;
  
  // Notifications
  getNotifications(userId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
  
  // Messages
  getMessages(userId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  updateMessageStatus(id: number, status: string): Promise<Message | undefined>;
  
  // Rewards
  getRewards(): Promise<Reward[]>;
  getReward(id: number): Promise<Reward | undefined>;
  createReward(reward: InsertReward): Promise<Reward>;
  
  // Settings
  getSettings(userId: number): Promise<Settings | undefined>;
  createSettings(settings: InsertSettings): Promise<Settings>;
  updateSettings(userId: number, settingsData: Partial<Settings>): Promise<Settings | undefined>;
  
  // Loyalty
  addLoyaltyPoints(userId: number, points: number): Promise<User | undefined>;
  
  // Treatment History
  getTreatments(userId: number): Promise<Treatment[]>;
  getTreatment(id: number): Promise<Treatment | undefined>;
  createTreatment(treatment: InsertTreatment): Promise<Treatment>;
  updateTreatment(id: number, treatmentData: Partial<Treatment>): Promise<Treatment | undefined>;
  deleteTreatment(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private appointments: Map<number, Appointment>;
  private medicalHistories: Map<number, MedicalHistory>;
  private notifications: Map<number, Notification>;
  private messages: Map<number, Message>;
  private rewards: Map<number, Reward>;
  private settings: Map<number, Settings>;
  private treatments: Map<number, Treatment>;
  
  private currentUserId: number;
  private currentAppointmentId: number;
  private currentMedicalHistoryId: number;
  private currentNotificationId: number;
  private currentMessageId: number;
  private currentRewardId: number;
  private currentSettingsId: number;
  private currentTreatmentId: number;

  constructor() {
    this.users = new Map();
    this.appointments = new Map();
    this.medicalHistories = new Map();
    this.notifications = new Map();
    this.messages = new Map();
    this.rewards = new Map();
    this.settings = new Map();
    this.treatments = new Map();
    
    this.currentUserId = 1;
    this.currentAppointmentId = 1;
    this.currentMedicalHistoryId = 1;
    this.currentNotificationId = 1;
    this.currentMessageId = 1;
    this.currentRewardId = 1;
    this.currentSettingsId = 1;
    this.currentTreatmentId = 1;
    
    // Initialize with some rewards
    this.initializeRewards();
  }

  // Helper to initialize rewards
  private initializeRewards() {
    const rewards = [
      {
        name: "Free Teeth Whitening",
        description: "Professional teeth whitening session",
        pointsCost: 500,
        isActive: true
      },
      {
        name: "Electric Toothbrush",
        description: "Premium electric toothbrush",
        pointsCost: 300,
        isActive: true
      },
      {
        name: "10% Off Next Visit",
        description: "Discount on your next dental service",
        pointsCost: 200,
        isActive: true
      }
    ];
    
    rewards.forEach(reward => {
      this.createReward({
        name: reward.name,
        description: reward.description,
        pointsCost: reward.pointsCost
      });
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const referralCode = `${insertUser.firstName.substring(0, 4).toUpperCase()}${nanoid(6)}`;
    const user: User = { 
      ...insertUser, 
      id, 
      loyaltyPoints: 0, 
      referralCode,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Appointment methods
  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }

  async getAppointmentsByUserId(userId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.userId === userId
    );
  }

  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = this.currentAppointmentId++;
    const appointment: Appointment = {
      ...insertAppointment,
      id,
      createdAt: new Date()
    };
    this.appointments.set(id, appointment);
    return appointment;
  }

  async updateAppointment(id: number, appointmentData: Partial<Appointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (!appointment) return undefined;
    
    const updatedAppointment = { ...appointment, ...appointmentData };
    this.appointments.set(id, updatedAppointment);
    return updatedAppointment;
  }

  async deleteAppointment(id: number): Promise<boolean> {
    return this.appointments.delete(id);
  }

  // Medical History methods
  async getMedicalHistory(userId: number): Promise<MedicalHistory | undefined> {
    return Array.from(this.medicalHistories.values()).find(
      (history) => history.userId === userId
    );
  }

  async createMedicalHistory(insertMedicalHistory: InsertMedicalHistory): Promise<MedicalHistory> {
    const id = this.currentMedicalHistoryId++;
    const medicalHistory: MedicalHistory = {
      ...insertMedicalHistory,
      id,
      updatedAt: new Date()
    };
    this.medicalHistories.set(id, medicalHistory);
    return medicalHistory;
  }

  async updateMedicalHistory(userId: number, medicalHistoryData: Partial<MedicalHistory>): Promise<MedicalHistory | undefined> {
    const medicalHistory = Array.from(this.medicalHistories.values()).find(
      (history) => history.userId === userId
    );
    if (!medicalHistory) return undefined;
    
    const updatedMedicalHistory = { 
      ...medicalHistory, 
      ...medicalHistoryData,
      updatedAt: new Date()
    };
    this.medicalHistories.set(medicalHistory.id, updatedMedicalHistory);
    return updatedMedicalHistory;
  }

  // Notification methods
  async getNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter((notification) => notification.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.currentNotificationId++;
    const notification: Notification = {
      ...insertNotification,
      id,
      read: false,
      createdAt: new Date()
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification = { ...notification, read: true };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }

  // Message methods
  async getMessages(userId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((message) => message.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      ...insertMessage,
      id,
      status: "unread",
      createdAt: new Date()
    };
    this.messages.set(id, message);
    return message;
  }

  async updateMessageStatus(id: number, status: string): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, status };
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }

  // Reward methods
  async getRewards(): Promise<Reward[]> {
    return Array.from(this.rewards.values()).filter(reward => reward.isActive);
  }

  async getReward(id: number): Promise<Reward | undefined> {
    return this.rewards.get(id);
  }

  async createReward(insertReward: InsertReward): Promise<Reward> {
    const id = this.currentRewardId++;
    const reward: Reward = {
      ...insertReward,
      id,
      isActive: true
    };
    this.rewards.set(id, reward);
    return reward;
  }

  // Settings methods
  async getSettings(userId: number): Promise<Settings | undefined> {
    return Array.from(this.settings.values()).find(
      (setting) => setting.userId === userId
    );
  }

  async createSettings(insertSettings: InsertSettings): Promise<Settings> {
    const id = this.currentSettingsId++;
    const settings: Settings = {
      ...insertSettings,
      id
    };
    this.settings.set(id, settings);
    return settings;
  }

  async updateSettings(userId: number, settingsData: Partial<Settings>): Promise<Settings | undefined> {
    const userSettings = Array.from(this.settings.values()).find(
      (setting) => setting.userId === userId
    );
    if (!userSettings) return undefined;
    
    const updatedSettings = { ...userSettings, ...settingsData };
    this.settings.set(userSettings.id, updatedSettings);
    return updatedSettings;
  }

  // Loyalty methods
  async addLoyaltyPoints(userId: number, points: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      loyaltyPoints: (user.loyaltyPoints || 0) + points 
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Treatment History methods
  async getTreatments(userId: number): Promise<Treatment[]> {
    return Array.from(this.treatments.values())
      .filter((treatment) => treatment.userId === userId)
      .sort((a, b) => {
        // Sort by date descending (most recent first)
        const dateA = new Date(a.treatmentDate).getTime();
        const dateB = new Date(b.treatmentDate).getTime();
        return dateB - dateA;
      });
  }

  async getTreatment(id: number): Promise<Treatment | undefined> {
    return this.treatments.get(id);
  }

  async createTreatment(insertTreatment: InsertTreatment): Promise<Treatment> {
    const id = this.currentTreatmentId++;
    const treatment: Treatment = {
      ...insertTreatment,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.treatments.set(id, treatment);
    return treatment;
  }

  async updateTreatment(id: number, treatmentData: Partial<Treatment>): Promise<Treatment | undefined> {
    const treatment = this.treatments.get(id);
    if (!treatment) return undefined;
    
    const updatedTreatment = {
      ...treatment,
      ...treatmentData,
      updatedAt: new Date()
    };
    this.treatments.set(id, updatedTreatment);
    return updatedTreatment;
  }

  async deleteTreatment(id: number): Promise<boolean> {
    return this.treatments.delete(id);
  }
}

export const storage = new MemStorage();
