import { useUser } from "@/context/UserContext";
import { Award } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const LoyaltyProgress = () => {
  const { user } = useUser();
  const currentPoints = user?.loyaltyPoints || 0;
  const targetPoints = 500;
  const progress = Math.min(Math.round((currentPoints / targetPoints) * 100), 100);
  
  const getTier = (points: number) => {
    if (points >= 1000) return "Gold";
    if (points >= 500) return "Silver";
    return "Bronze";
  };
  
  const getNextTier = (currentTier: string) => {
    if (currentTier === "Bronze") return "Silver";
    if (currentTier === "Silver") return "Gold";
    return "Platinum";
  };
  
  const getPointsToNextTier = (points: number) => {
    if (points < 500) return 500 - points;
    if (points < 1000) return 1000 - points;
    return 0;
  };
  
  const currentTier = getTier(currentPoints);
  const nextTier = getNextTier(currentTier);
  const pointsToNextTier = getPointsToNextTier(currentPoints);
  
  return (
    <Card>
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-3">Your Progress</h2>
        
        <div className="mb-6">
          <div className="flex justify-between text-sm mb-2">
            <span>{currentPoints}</span>
            <span>{targetPoints}</span>
          </div>
          <div className="h-2 bg-neutral-200 rounded">
            <div 
              className="h-2 bg-amber-500 rounded" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          <p className="text-sm text-neutral-600 mt-2">
            You're {progress}% of the way to free teeth whitening!
          </p>
        </div>
        
        <div className="p-4 bg-amber-500 bg-opacity-10 rounded-lg flex items-center">
          <div className="w-12 h-12 bg-amber-500 bg-opacity-20 rounded-full flex items-center justify-center">
            <Award className="h-6 w-6 text-amber-500" />
          </div>
          <div className="ml-4">
            <h3 className="font-medium">Current Tier: {currentTier}</h3>
            {pointsToNextTier > 0 && (
              <p className="text-sm text-neutral-600">
                Earn {pointsToNextTier} more points to reach {nextTier} Tier!
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default LoyaltyProgress;
