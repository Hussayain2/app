import PageContainer from "@/components/layout/PageContainer";
import ProfileInfo from "@/components/profile/ProfileInfo";
import MedicalHistory from "@/components/profile/MedicalHistory";
import AccountSettings from "@/components/profile/AccountSettings";

const ProfilePage = () => {
  return (
    <PageContainer title="Your Profile">
      <ProfileInfo />
      <MedicalHistory />
      <AccountSettings />
    </PageContainer>
  );
};

export default ProfilePage;
