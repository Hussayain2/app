import { useState } from "react";
import { useUser } from "@/context/UserContext";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Share, UserPlus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const inviteFormSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type InviteFormValues = z.infer<typeof inviteFormSchema>;

const ReferralProgram = () => {
  const { user, setUser } = useUser();
  const { toast } = useToast();
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<InviteFormValues>({
    resolver: zodResolver(inviteFormSchema),
    defaultValues: {
      email: "",
    },
  });
  
  const referralCode = user?.referralCode || "DENTALREF123";
  
  const handleCopyReferralCode = () => {
    navigator.clipboard.writeText(referralCode);
    toast({
      title: "Copied!",
      description: "Referral code copied to clipboard",
    });
  };
  
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Join DentalConnect",
          text: `Use my referral code ${referralCode} to join DentalConnect and get a discount on your first visit!`,
          url: window.location.origin,
        });
        toast({
          title: "Shared!",
          description: "Thanks for sharing DentalConnect",
        });
      } catch (error) {
        console.error("Error sharing:", error);
      }
    } else {
      handleCopyReferralCode();
    }
  };
  
  const onSubmit = async (data: InviteFormValues) => {
    setIsSubmitting(true);
    try {
      const response = await apiRequest("POST", "/api/referrals", { email: data.email });
      const responseData = await response.json();
      
      if (responseData.user) {
        setUser(responseData.user);
      }
      
      toast({
        title: "Referral Sent!",
        description: `Invitation sent to ${data.email}. You've earned 100 loyalty points!`,
      });
      
      setIsInviteDialogOpen(false);
      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send referral. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <>
      <Card>
        <CardContent className="p-4">
          <h2 className="text-lg font-semibold mb-3">Refer a Friend</h2>
          
          <p className="text-neutral-600 mb-4">
            Invite friends and family to our dental clinic and earn 100 points for each successful referral!
          </p>
          
          <div className="p-4 bg-neutral-100 rounded-lg mb-4 flex">
            <Input
              type="text"
              value={referralCode}
              readOnly
              className="flex-1 bg-transparent border-none text-neutral-800 focus-visible:ring-0"
            />
            <Button 
              variant="ghost" 
              className="text-primary font-medium"
              onClick={handleCopyReferralCode}
            >
              Copy
            </Button>
          </div>
          
          <div className="flex space-x-3">
            <Button 
              className="flex-1 gap-2"
              onClick={handleShare}
            >
              <Share className="h-4 w-4" />
              <span>Share</span>
            </Button>
            <Button 
              variant="outline"
              className="flex-1 gap-2 border-primary text-primary"
              onClick={() => setIsInviteDialogOpen(true)}
            >
              <UserPlus className="h-4 w-4" />
              <span>Invite</span>
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Invite a Friend</DialogTitle>
            <DialogDescription>
              Send an invitation to your friend and earn 100 loyalty points when they join.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Friend's Email</FormLabel>
                    <FormControl>
                      <Input placeholder="email@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsInviteDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Sending..." : "Send Invitation"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ReferralProgram;
