import { format, formatDistanceToNow } from "date-fns";

export const formatDate = (date: string | Date): string => {
  const d = typeof date === "string" ? new Date(date) : date;
  return format(d, "MMMM d, yyyy");
};

export const formatTime = (time: string): string => {
  return time;
};

export const formatTimeAgo = (date: string | Date): string => {
  const d = typeof date === "string" ? new Date(date) : date;
  return formatDistanceToNow(d, { addSuffix: true });
};

export const generateMonthDays = (year: number, month: number): Date[] => {
  const result: Date[] = [];
  const date = new Date(year, month, 1);
  
  while (date.getMonth() === month) {
    result.push(new Date(date));
    date.setDate(date.getDate() + 1);
  }
  
  return result;
};

export const getMonthName = (month: number): string => {
  return format(new Date(2000, month, 1), "MMMM");
};

export const getDayOfWeek = (day: number): string => {
  return format(new Date(2000, 0, day), "EEE");
};
