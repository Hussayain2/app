import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PageContainer from "@/components/layout/PageContainer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Plus, CalendarDays, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { BriefcaseMedical, User, DollarSign } from "lucide-react";
import { formatDate } from "@/lib/dates";
import { Treatment } from "@shared/schema";
import TreatmentDetails from "@/components/treatments/TreatmentDetails";
import AddTreatmentForm from "@/components/treatments/AddTreatmentForm";

export default function TreatmentHistoryPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTreatment, setSelectedTreatment] = useState<Treatment | null>(null);
  const [isAddingTreatment, setIsAddingTreatment] = useState(false);
  
  // Fetch treatments
  const { data: treatments = [], isLoading } = useQuery<Treatment[]>({
    queryKey: ["/api/treatments"],
  });
  
  // Filter treatments based on search term
  const filteredTreatments = treatments.filter(treatment => {
    const searchLower = searchTerm.toLowerCase();
    return (
      treatment.description.toLowerCase().includes(searchLower) ||
      treatment.treatmentType.toLowerCase().includes(searchLower) ||
      (treatment.dentistName && treatment.dentistName.toLowerCase().includes(searchLower))
    );
  });

  // Sort treatments by date (newest first)
  const sortedTreatments = [...filteredTreatments].sort((a, b) => {
    return new Date(b.treatmentDate).getTime() - new Date(a.treatmentDate).getTime();
  });
  
  // Group treatments by year and month
  const groupedTreatments: Record<string, Treatment[]> = {};
  
  sortedTreatments.forEach(treatment => {
    const date = new Date(treatment.treatmentDate);
    const yearMonth = `${date.getFullYear()}-${date.getMonth()}`;
    
    if (!groupedTreatments[yearMonth]) {
      groupedTreatments[yearMonth] = [];
    }
    
    groupedTreatments[yearMonth].push(treatment);
  });
  
  if (selectedTreatment) {
    return (
      <TreatmentDetails 
        treatment={selectedTreatment} 
        onClose={() => setSelectedTreatment(null)} 
      />
    );
  }
  
  if (isAddingTreatment) {
    return (
      <AddTreatmentForm onClose={() => setIsAddingTreatment(false)} />
    );
  }

  return (
    <PageContainer title="Treatment History">
      <div className="space-y-4">
        {/* Search and Add */}
        <div className="flex flex-col md:flex-row gap-4 justify-between">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              type="text"
              placeholder="Search treatments..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button onClick={() => setIsAddingTreatment(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Treatment
          </Button>
        </div>
        
        {isLoading ? (
          // Loading state
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="opacity-70">
                <CardHeader>
                  <div className="h-6 bg-gray-200 rounded animate-pulse w-1/3"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="h-12 bg-gray-200 rounded animate-pulse"></div>
                    <div className="h-12 bg-gray-200 rounded animate-pulse"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : sortedTreatments.length === 0 ? (
          // Empty state
          <Card className="bg-gray-50 border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <BriefcaseMedical className="h-12 w-12 text-gray-400 mb-4" />
              <CardTitle className="text-xl font-medium text-gray-600 mb-2">No treatments yet</CardTitle>
              <p className="text-gray-500 text-center mb-6">
                {searchTerm 
                  ? "No treatments match your search. Try a different term."
                  : "Your dental treatment history will appear here once you add treatments."}
              </p>
              <Button onClick={() => setIsAddingTreatment(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Treatment
              </Button>
            </CardContent>
          </Card>
        ) : (
          // Treatment list grouped by month
          <div className="space-y-6">
            {Object.entries(groupedTreatments).map(([yearMonth, treatments]) => {
              const [year, month] = yearMonth.split('-').map(Number);
              const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
              const monthName = monthNames[month];
              
              return (
                <div key={yearMonth} className="space-y-3">
                  <h3 className="font-semibold text-gray-700 flex items-center">
                    <CalendarDays className="h-4 w-4 mr-2 text-primary" />
                    {monthName} {year}
                  </h3>
                  <div className="space-y-3">
                    {treatments.map((treatment) => (
                      <Card 
                        key={treatment.id} 
                        className="hover:bg-gray-50 cursor-pointer transition-colors"
                        onClick={() => setSelectedTreatment(treatment)}
                      >
                        <CardContent className="p-4">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            <div className="space-y-1">
                              <p className="text-sm text-gray-500">Date</p>
                              <p className="font-medium flex items-center">
                                <CalendarDays className="h-4 w-4 mr-2 text-primary" />
                                {formatDate(treatment.treatmentDate)}
                              </p>
                            </div>
                            
                            <div className="space-y-1">
                              <p className="text-gray-500 text-sm">Treatment</p>
                              <div className="flex items-center space-x-2">
                                <p className="font-medium truncate">{treatment.description}</p>
                                <Badge
                                  variant={
                                    treatment.treatmentType === "preventive" ? "outline" :
                                    treatment.treatmentType === "cosmetic" ? "secondary" :
                                    treatment.treatmentType === "surgical" ? "destructive" : "default"
                                  }
                                  className="text-xs"
                                >
                                  {treatment.treatmentType}
                                </Badge>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-3">
                              <div className="space-y-1">
                                <p className="text-gray-500 text-sm">Dentist</p>
                                <p className="font-medium flex items-center">
                                  <User className="h-4 w-4 mr-2 text-primary" />
                                  {treatment.dentistName || "N/A"}
                                </p>
                              </div>
                              
                              <div className="space-y-1">
                                <p className="text-gray-500 text-sm">Cost</p>
                                <div className="flex items-center justify-between">
                                  <p className="font-medium flex items-center">
                                    <DollarSign className="h-4 w-4 mr-2 text-primary" />
                                    ${parseFloat(treatment.cost).toFixed(2)}
                                  </p>
                                  <Badge variant={treatment.isPaid ? "default" : "outline"}>
                                    {treatment.isPaid ? "Paid" : "Unpaid"}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </PageContainer>
  );
}