import { useLocation } from "wouter";
import { Calendar, MessageSquare, UserPlus, Award } from "lucide-react";
import { cn } from "@/lib/utils";

const QuickActions = () => {
  const [, navigate] = useLocation();
  
  const actions = [
    {
      name: "Book Appointment",
      icon: Calendar,
      color: "bg-blue-50 text-blue-600",
      onClick: () => navigate("/appointments"),
      iconDecorator: (
        <svg viewBox="0 0 36 36" className="absolute inset-0 w-full h-full opacity-5">
          <path d="M30,8H26V6a2,2,0,0,0-2-2H22a2,2,0,0,0-2,2V8H16V6a2,2,0,0,0-2-2H12a2,2,0,0,0-2,2V8H6a2,2,0,0,0-2,2V30a2,2,0,0,0,2,2H30a2,2,0,0,0,2-2V10A2,2,0,0,0,30,8Z" fill="currentColor"/>
        </svg>
      ),
    },
    {
      name: "Message Clinic",
      icon: MessageSquare,
      color: "bg-green-50 text-green-600",
      onClick: () => navigate("/contact"),
      iconDecorator: (
        <svg viewBox="0 0 36 36" className="absolute inset-0 w-full h-full opacity-5">
          <path d="M32,6H4A2,2,0,0,0,2,8V28a2,2,0,0,0,2,2H32a2,2,0,0,0,2-2V8A2,2,0,0,0,32,6ZM30,26H6V10H30Z" fill="currentColor"/>
        </svg>
      ),
    },
    {
      name: "Refer a Friend",
      icon: UserPlus,
      color: "bg-purple-50 text-purple-600",
      onClick: () => navigate("/rewards"),
      iconDecorator: (
        <svg viewBox="0 0 36 36" className="absolute inset-0 w-full h-full opacity-5">
          <path d="M32,16H30v-2a2,2,0,0,0-2-2H26V10a2,2,0,0,0-2-2H22a2,2,0,0,0-2,2v2H16V10a2,2,0,0,0-2-2H12a2,2,0,0,0-2,2v2H6a2,2,0,0,0-2,2v2H2a2,2,0,0,0-2,2v8a2,2,0,0,0,2,2H4v2a2,2,0,0,0,2,2H32a2,2,0,0,0,2-2V18A2,2,0,0,0,32,16Z" fill="currentColor"/>
        </svg>
      ),
    },
    {
      name: "Loyalty Rewards",
      icon: Award,
      color: "bg-amber-50 text-amber-600",
      onClick: () => navigate("/rewards"),
      iconDecorator: (
        <svg viewBox="0 0 36 36" className="absolute inset-0 w-full h-full opacity-5">
          <path d="M18,4a8,8,0,0,0-8,8c0,8,8,16,8,16s8-8,8-16A8,8,0,0,0,18,4Z" fill="currentColor"/>
        </svg>
      ),
    },
  ];
  
  return (
    <div className="mb-8">
      <h2 className="text-lg font-bold mb-4 text-gray-900">Quick Actions</h2>
      <div className="grid grid-cols-2 gap-4">
        {actions.map((action) => (
          <button
            key={action.name}
            onClick={action.onClick}
            className="relative group bg-white rounded-2xl shadow-lg border border-gray-100 p-5 flex flex-col items-center text-center transition-all hover:shadow-xl hover:-translate-y-1"
          >
            <div className={cn(
              "relative w-14 h-14 rounded-xl flex items-center justify-center mb-3 transition-all",
              action.color
            )}>
              {action.iconDecorator}
              <action.icon className="h-6 w-6 z-10" />
            </div>
            <span className="font-medium text-gray-800">{action.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;
