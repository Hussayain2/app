import { useQuery } from "@tanstack/react-query";
import { Bell, Award } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Notification } from "@shared/schema";

const NotificationItem = ({ notification }: { notification: Notification }) => {
  let icon = <Bell className="text-primary" />;
  let bgColor = "bg-primary";
  
  if (notification.type === "loyalty") {
    icon = <Award className="text-secondary" />;
    bgColor = "bg-secondary";
  }
  
  const timeAgo = formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true });
  
  return (
    <div className="bg-white rounded-xl shadow-card p-4 flex space-x-3">
      <div className={`w-10 h-10 ${bgColor} bg-opacity-10 rounded-full flex items-center justify-center flex-shrink-0`}>
        {icon}
      </div>
      <div className="flex-1">
        <h3 className="font-medium">{notification.title}</h3>
        <p className="text-sm text-neutral-600">{notification.message}</p>
        <p className="text-xs text-neutral-500 mt-1">{timeAgo}</p>
      </div>
    </div>
  );
};

const Notifications = () => {
  const { data: notifications = [], isLoading } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });
  
  if (isLoading) {
    return (
      <div>
        <h2 className="text-lg font-semibold mb-3">Notifications</h2>
        <div className="space-y-3">
          <div className="bg-white rounded-xl shadow-card p-4 h-20 animate-pulse" />
          <div className="bg-white rounded-xl shadow-card p-4 h-20 animate-pulse" />
        </div>
      </div>
    );
  }
  
  if (notifications.length === 0) {
    return (
      <div>
        <h2 className="text-lg font-semibold mb-3">Notifications</h2>
        <div className="bg-white rounded-xl shadow-card p-4 text-center">
          <p className="text-neutral-600">No notifications yet</p>
        </div>
      </div>
    );
  }
  
  return (
    <div>
      <h2 className="text-lg font-semibold mb-3">Notifications</h2>
      <div className="space-y-3">
        {notifications.slice(0, 3).map((notification) => (
          <NotificationItem key={notification.id} notification={notification} />
        ))}
      </div>
    </div>
  );
};

export default Notifications;
