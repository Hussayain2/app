import React from "react";
import { cn } from "@/lib/utils";

interface PageContainerProps {
  children: React.ReactNode;
  title?: string;
  className?: string;
  noPadding?: boolean;
}

const PageContainer = ({ 
  children, 
  title, 
  className,
  noPadding = false
}: PageContainerProps) => {
  return (
    <main className={cn(
      "flex-1 overflow-y-auto pb-20 bg-gray-50/50",
      !noPadding && "px-4 py-6 space-y-6",
      className
    )}>
      {title && <h1 className="text-2xl font-bold text-gray-900">{title}</h1>}
      <div className="max-w-screen-md mx-auto">
        {children}
      </div>
    </main>
  );
};

export default PageContainer;
